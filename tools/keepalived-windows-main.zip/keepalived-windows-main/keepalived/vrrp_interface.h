#pragma once
#include<string>
using namespace std;

void add_vip(const string ip, const string mask, const string interface_name);

void remove_vip(const string ip, const string interface_name);
